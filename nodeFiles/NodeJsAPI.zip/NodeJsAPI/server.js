//mongoDB connection string
//mongodb+srv://raj:<password>@nodejsdemomongocluster-qkwh8.azure.mongodb.net/test?retryWrites=true&w=majority


var express = require('express');
var cors = require('cors');
var app = express();
var port = process.env.port || 8008;


app.use(cors());


var bodyParser = require('body-parser');

// create application/x-www-form-urlencoded parser
app.use(bodyParser.urlencoded({ extended: true }));

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "PUT, GET, POST, DELETE, OPTIONS" );
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});


// create application/json parser
app.use(bodyParser.json());

 
var userController=require('./controller/usercontroller')();


app.use("/",userController);
 
app.listen(port, function () {
    var datetime = new Date();
    var message = "Server runnning on Port:- " + port + " Started at :- " + datetime;
    console.log(message);
});
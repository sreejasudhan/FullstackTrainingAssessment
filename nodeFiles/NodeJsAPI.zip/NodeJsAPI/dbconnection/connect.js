var sql = require("mssql");
const mondoDBConURL="mongodb://localhost:27017/AbcBank";

var connect = function()
{
    var conn = new sql.ConnectionPool({
        server: 'localhost',
        database: 'MyDB',
        user: 'sa',
        password: 'sa@12345',
        port: 1433
    });
 
    return conn;
};

var mongodbconnecturl = function()
{
    return mondoDBConURL;
};

module.exports = {connect:connect,mongodbconnecturl:mongodbconnecturl};
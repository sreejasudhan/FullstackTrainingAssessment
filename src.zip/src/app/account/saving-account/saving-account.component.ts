import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-saving-account',
  templateUrl: './saving-account.component.html',
  styleUrls: ['./saving-account.component.css']
})
export class SavingAccountComponent implements OnInit {

@Input() userDetails: any;
element: any;

  constructor() { }

  ngOnInit() {

  this.element = this.userDetails;
  console.log(this.element,"this.saving---");
  }

}

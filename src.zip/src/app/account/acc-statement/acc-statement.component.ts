import { Component, OnInit , Input } from '@angular/core';

@Component({
  selector: 'app-acc-statement',
  templateUrl: './acc-statement.component.html',
  styleUrls: ['./acc-statement.component.css']
})
export class AccStatementComponent implements OnInit {

  constructor() { }

  ngOnInit() {

  this.element =  JSON.parse(localStorage.getItem('currentUser'));
  }

}

import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-current-account',
  templateUrl: './current-account.component.html',
  styleUrls: ['./current-account.component.css']
})
export class CurrentAccountComponent implements OnInit {
@Input() userDetails: any;
element : any;
  constructor() { }

  ngOnInit() {

  this.element = this.userDetails;
  console.log(this.element,"current---");
  }

}

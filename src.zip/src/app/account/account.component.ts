import { Component, OnInit } from '@angular/core';
import { UserService } from '../_services/user.service';
import { Observable, throwError } from 'rxjs';
import { map, catchError} from 'rxjs/operators';
import { UserAccount } from '../_models/userAccount';
import { HttpClient } from "@angular/common/http";
import { SharingService } from '../_services/sharing.service';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {
 customerDetail: any;
 getBtnText = "Saving Account";
  userNameParam : any;
  constructor(private userService: UserService, private sharingService:SharingService,
               private httpClient: HttpClient) { }
 
      ngOnInit() {  
          this.customerDetail = JSON.parse(localStorage.getItem('currentUser'));
           }

       onselectBtn(getText: string){
      this.getBtnText = getText;
      
       }
}

import { Component, OnInit } from '@angular/core';
import { first } from 'rxjs/operators';
import { User } from '../_models/user';
import { HttpClient } from "@angular/common/http";
import { AuthenticationService } from '../_services/authentication.service';
import { UserService } from '../_services/user.service';
import { SharingService } from '../_services/sharing.service';
import { UserDetail } from '../_models/userDetail';

@Component({ templateUrl: 'home.component.html' })
export class HomeComponent implements OnInit {
    currentUser: User;
    userNameParam : string;
    customerDetail: any;
    users = [];
  loadedText = "account";
    constructor(
        private authenticationService: AuthenticationService,private sharingService:SharingService,
        private userService: UserService,
    ) {
        this.currentUser = this.authenticationService.currentUserValue;
    }

    ngOnInit() {
        this.loadAllUsers();
        this.getAccountSummary();
       // this.getAccountDetail();
     this.userNameParam = JSON.parse(localStorage.getItem('currentUser'));
      
    }
    
    onselectText(getText: string){
    this.loadedText = getText;
}

    deleteUser(id: number) {
        this.userService.delete(id)
            .pipe(first())
            .subscribe(() => this.loadAllUsers());
    }

    private loadAllUsers() {
        this.userService.getAll()
            .pipe(first())
            .subscribe(users => this.users = users);
    }
    getAccountSummary(){
    
this.userService.getAccountDetail(this.userName).subscribe(
        (response: any) => {  //next() callback
            console.log( 'response received');      
          this.customerDetail = response;
          //console.log(this.customerDetail ,'home---');
          this.sharingService.setData(this.customerDetail); 
        },
        (error) => {                              //error() callback
          console.error('Request failed with error', error);
        });
}
//menu link


}
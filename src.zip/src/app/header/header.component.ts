import { Component, OnInit, EventEmitter, Output} from '@angular/core';

import { SharingService } from '../_services/sharing.service';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  serviceData: any;
  userRole : string;
  currentLink: string
 @Output() featureText = new EventEmitter<string>();

  constructor(private sharingService:SharingService) { }
 getData(){ 
 setTimeout(()=>{ 
this.serviceData = JSON.parse(localStorage.getItem('currentUser'));
  this.userRole = this.serviceData.role;  
  console.log( this.serviceData ,'header>>>>--');
    },3000);
     
 }
  ngOnInit() {
   this.getData();
  }
 		onselectLink(getText: string){
	     this.featureText.emit(getText);
	     console.log( this.featureText,'----------');
       }
}

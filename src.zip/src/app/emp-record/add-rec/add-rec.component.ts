import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-rec',
  templateUrl: './add-rec.component.html',
  styleUrls: ['./add-rec.component.css']
})
export class AddRecComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

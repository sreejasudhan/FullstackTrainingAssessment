import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp-table',
  templateUrl: './emp-table.component.html',
  styleUrls: ['./emp-table.component.css']
})
export class EmpTableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

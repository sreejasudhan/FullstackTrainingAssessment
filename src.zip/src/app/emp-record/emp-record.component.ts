import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-emp-record',
  templateUrl: './emp-record.component.html',
  styleUrls: ['./emp-record.component.css']
})
export class EmpRecordComponent implements OnInit {
@Input() empDetail: {userName: string, password: string}
  constructor() { }

  ngOnInit(): void {
  }

}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { User } from '../_models/user';
import { UserDetail } from '../_models/userDetail';

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
    private currentUserSubject: BehaviorSubject<UserDetail>;
    public currentUser: Observable<UserDetail>;

    constructor(private http: HttpClient) {
        this.currentUserSubject = new BehaviorSubject<UserDetail>(JSON.parse(localStorage.getItem('currentUser')));
        this.currentUser = this.currentUserSubject.asObservable();
        console.log( this.currentUser ,'auth');
    }

    public get currentUserValue(): UserDetail {
        return this.currentUserSubject.value;
    }

 login(username: string, password: string) {
        return this.http.post<any>(`${environment.apiUrl}/api/userlogin`, { username, password })
            .pipe(map(user => {
            console.log(user.token,'token');
               if (user && user.token) {
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
                    localStorage.setItem('currentUser', JSON.stringify(user));
                    this.currentUserSubject.next(user);
                }

                return user;
            }));
    }

   logout() {
        // remove user from local storage and set current user to null
        localStorage.removeItem('currentUser');
        this.currentUserSubject.next(null);
    }
}


import { Injectable } from '@angular/core';
import {Observable } from 'rxjs';
import { HttpClient, HttpErrorResponse,HttpHeaders, HttpParams, HttpResponse} from '@angular/common/http';
import { environment } from '../../environments/environment';
import { User } from '../_models/user';
import { UserAccount } from '../_models/userAccount';
import { UserDetail } from '../_models/userDetail';


@Injectable({ providedIn: 'root' })
export class UserService {
    constructor(private http: HttpClient,
     private httpClient: HttpClient) { }

    getAll() {
        return this.http.get<UserDetail[]>(`${environment.apiUrl}/api/AllAccountDetails`);
    }

getAccountDetail(username: string) {
    //return this.httpClient.get("assets/empData.json");    
    return this.http.get<UserDetail[]>(`${environment.apiUrl}/api/AccountDetails/${username}`);
}

    register(user: User) {
        return this.http.post(`${environment.apiUrl}/users/register`, user);
    }

    delete(id: number) {
        return this.http.delete(`${environment.apiUrl}/users/${id}`);
    }
}

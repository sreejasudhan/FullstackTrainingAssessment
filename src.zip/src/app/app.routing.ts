import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { AccountComponent } from './account/account.component';
import { AccStatementComponent } from './account/acc-statement/acc-statement.component';
import { TransactionsComponent } from './transactions/transactions.component';
//import { UpdateProfileComponent } from './update-profile/update-profile.component';
import { AuthGuard } from './_helpers/auth.guard';

const routes: Routes = [
    { path: '', component: HomeComponent, canActivate: [AuthGuard] },
    { path: 'login', component: LoginPageComponent },
     //{ path: 'account', component: AccountComponent },
    //  { path: 'transactions', component: TransactionsComponent },
     //  { path: 'update', component: UpdateProfileComponent },

    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];

export const appRoutingModule = RouterModule.forRoot(routes);
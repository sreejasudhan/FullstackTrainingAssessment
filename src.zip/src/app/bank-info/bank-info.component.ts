import { Component, OnInit } from '@angular/core';
import { SharingService } from '../_services/sharing.service';
@Component({
  selector: 'app-bank-info',
  templateUrl: './bank-info.component.html',
  styleUrls: ['./bank-info.component.css']
})
export class BankInfoComponent implements OnInit {
getDetalJson: any;
  constructor(private sharingService:SharingService) { }

  ngOnInit(): void {
    this.getDetalJson = this.sharingService.getData(); 
    console.log( this.getDetalJson ,'----');
  }

}

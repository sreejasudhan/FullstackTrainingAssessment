import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SharingService } from '../_services/sharing.service';
import { Observable } from 'rxjs';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit {
getDetalJson : any;
contact: any;
  constructor(private sharingService:SharingService) { }

  ngOnInit(): void {
  
  this.getDetalJson = this.sharingService.getData(); 
  this.contact = this.getDetalJson.transaction;
   }

 

}

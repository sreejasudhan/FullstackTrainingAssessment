import { Component, OnInit } from '@angular/core';
import { UserAccount } from '../_models/userAccount';
import { SharingService } from '../_services/sharing.service';
@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css']
})
export class TransactionsComponent implements OnInit {
getBtnText ="Detail Statement";
customerDetail : any;
customerTransaction : any;

  constructor(private sharingService:SharingService) { }
  
  ngOnInit() {
  this.customerTransaction = this.sharingService.getData(); 
  this.customerDetail = this.customerTransaction.transaction
  }
 onselectBtn(getText: string){
	this.getBtnText = getText;
	console.log(getText,'getText');
 }




}

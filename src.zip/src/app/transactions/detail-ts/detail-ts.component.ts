import { Component, OnInit, Input,ViewEncapsulation, ViewChild, ElementRef } from '@angular/core';
import * as xlsx from 'xlsx';
@Component({
  selector: 'app-detail-ts',
  templateUrl: './detail-ts.component.html',
  styleUrls: ['./detail-ts.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class DetailTsComponent implements OnInit {
 @ViewChild('epltable', { static: false }) epltable: ElementRef;
@Input() transDetails: any;
public searchString: string;
element: any;

  constructor() { }

  ngOnInit() {

    this.element = this.transDetails;
  console.log("this.saving--- Detail");
  }
  exportToExcel() {
  const ws: xlsx.WorkSheet =   
  xlsx.utils.table_to_sheet(this.epltable.nativeElement);
  const wb: xlsx.WorkBook = xlsx.utils.book_new();
  xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
  xlsx.writeFile(wb, 'epltable1.xlsx');
 }


}

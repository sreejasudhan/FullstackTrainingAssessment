import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-min-ts',
  templateUrl: './min-ts.component.html',
  styleUrls: ['./min-ts.component.css']
})
export class MinTsComponent implements OnInit {
@Input() transDetails: any;
element: any;
  constructor() { }

  ngOnInit(): void {
    console.log("this.saving--- Mini");
     this.element = this.transDetails;
  }

}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';

// used to create fake backend
import { fakeBackendProvider } from './_helpers/fake-backend';
import { appRoutingModule } from './app.routing';
import { BasicAuthInterceptor } from './_helpers/basic-auth.interceptor';

import { ErrorInterceptor } from './_helpers/error.interceptor';

import { FilterPipe } from './_filter/filter.pipe';
import { AppComponent } from './app.component';
import { EmpRecordComponent } from './emp-record/emp-record.component';
import { AddRecComponent } from './emp-record/add-rec/add-rec.component';
import { EmpTableComponent } from './emp-record/emp-table/emp-table.component';

import { LoginPageComponent } from './login-page/login-page.component';
import { AccountComponent } from './account/account.component';
import { UserComponent } from './user/user.component';
import { HomeComponent } from './home/home.component';
import { AlertComponent } from './alert/alert.component';
import { AccStatementComponent } from './account/acc-statement/acc-statement.component';
import { HeaderComponent } from './header/header.component';
import { SavingAccountComponent } from './account/saving-account/saving-account.component';
import { CurrentAccountComponent } from './account/current-account/current-account.component';
import { TransactionsComponent } from './transactions/transactions.component';
import { DetailTsComponent } from './transactions/detail-ts/detail-ts.component';
import { MinTsComponent } from './transactions/min-ts/min-ts.component';
import { SharingService } from './_services/sharing.service';
import { UpdateProfileComponent } from './update-profile/update-profile.component';
import { BankInfoComponent } from './bank-info/bank-info.component';
/*
const appRouter : Routes = [
{path:'',component:HomeComponent},
{path:'users',component:UserComponent},
{path:'accDetails',component:AccountComponent}

];*/


@NgModule({
  declarations: [
    AppComponent,
    EmpRecordComponent,
    AddRecComponent,
    EmpTableComponent,
    LoginPageComponent,
    AccountComponent,
    HomeComponent,
    AlertComponent,
    AccStatementComponent,
    HeaderComponent,
    SavingAccountComponent,
    CurrentAccountComponent,
    TransactionsComponent,
    DetailTsComponent,
    MinTsComponent,
    FilterPipe,
    UpdateProfileComponent,
    BankInfoComponent
        
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    appRoutingModule
    
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: BasicAuthInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },

        // provider used to create fake backend
        fakeBackendProvider,
        SharingService
        ],
  bootstrap: [AppComponent]
})
export class AppModule { }


    export class Details {
        firstName: string;
        lastName: string;
        address: string;
        contact: number;
        email: string;
        savingAmount: number;
        currentAmount: number;        
    }

    export class Transaction {
        transactionDate: string;
        transactionRemarks: string;
        transactionType: string;
        balanceOnDate: number;
        transactionAmount: number;
        fromAccNumber: string;
        toAccNumber: string;
        TransactionTimeStamp: string;
        TransactionId: string;
        transactionStatus: string;
    }

    export class UserDetail {
        accountNumber: string;
        userName: string;
        role: string;
        details: Details;
        transaction: Transaction[];
        id: number;
        username: string ;
        password: string ;
        firstName: string;
        lastName: string;   
        token: string; 
    }

